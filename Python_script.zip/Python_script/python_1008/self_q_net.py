# -*- coding: utf-8 -*-

import chainer
import copy
import numpy as np
from chainer import cuda, Chain, Variable, optimizers
#from chainer import cuda, Chain, Variable, optimizers
import chainer.functions as F
import chainer.links as L
import pickle as pickle

import numpy as np
from mpi4py import MPI      #for MPI
import time
import random

import array
import random

from deap import algorithms  #for (mu,lambda)-ES
from deap import base
from deap import benchmarks
from deap import creator
from deap import tools


class QNet:
    # Hyper-Parameters
    gamma = 0.95  # Discount factor
    timestep_per_episode = 2000
    maxEpisode =1000 #In DRL 50 add by Louis 2019.8.3
    selection_number=2
    #initial_exploration = timestep_per_episode * 1  # Initial exploratoin. original: 5x10^4
    initial_exploration = 0  # Initial exploratoin. original: 5x10^4

    #initial_exploration = 40  # Initial exploratoin. original: 5x10^4
    replay_size = 32  # Replay (batch) size
    hist_size = 4  # original: 4 the info imported into NN add by Louis 2019.8.1
    data_index = 0
    data_flag = False

    def __init__(self, use_gpu, enable_controller, cnn_input_dim,
                 feature_dim, agent_count, other_input_dim, model,initial,num_of_controller,evolution,mu,lambda_,BN_evo,log,logDirPath):
        self.use_gpu = use_gpu
        #self.num_of_actions = len(enable_controller) // edit in 19.11.21 for continuous
        self.num_of_actions = 2 
        self.enable_controller = enable_controller
        self.cnn_input_dim = cnn_input_dim
        self.feature_dim = feature_dim
        self.agent_count = agent_count
        self.other_input_dim = other_input_dim
        #self.data_size = self.timestep_per_episode 
        self.data_size = 5000

        self.num_of_controller = num_of_controller        #add by morimoto
        self.evolution = evolution
        self.mu = mu
        self.lambda_ = lambda_
        self.BN_evo = BN_evo
        self.log=log
        self.logDirPath=logDirPath
        self.data_index = [0]*self.num_of_controller 
        self.data_flag = [False]*self.num_of_controller 

        #for evolution
        self.parent_reward=0
        self.child_reward=0
        
        #for multi controller
        self.controllers=[]
        self.optimizers=[]
        self.temp_best_weights=[]

        #come lists for weights of ANN 
        self.list_for_weights_in_first_of_episode=[0]*self.num_of_controller     #this list add for multi controller mode

        print ("Initializing Q-Network...")

        if model == 'None':
            for i in range(0,self.num_of_controller):
                self.model = Chain(
                    conv1=L.Convolution2D(3 * self.hist_size, 64, 4, stride=2),
                    bn1=L.BatchNormalization(64),
                    conv2=L.Convolution2D(64, 64, 4, stride=2),
                    bn2=L.BatchNormalization(64),
                    conv3=L.Convolution2D(64, 64, 4, stride=2),
                    bn3=L.BatchNormalization(64),
                    conv4=L.Convolution2D(64, 64, 4, stride=2),
                    bn4=L.BatchNormalization(64),
                    l1=L.Linear(self.feature_dim + self.other_input_dim * self.hist_size, 256),
                    q_value=L.Linear(256, self.num_of_actions)
                )
        
                if self.use_gpu >= 0:
                    chainer.backends.cuda.get_device_from_id(self.use_gpu).use()
                    self.model.to_gpu()

                weights=[]
                weights.append(copy.deepcopy(self.model.conv1.W.data))
                weights.append(copy.deepcopy(self.model.conv2.W.data))
                weights.append(copy.deepcopy(self.model.conv3.W.data))
                weights.append(copy.deepcopy(self.model.conv4.W.data))
                weights.append(copy.deepcopy(self.model.l1.W.data))
                weights.append(copy.deepcopy(self.model.q_value.W.data)) 
                #remaing part was add by morimoto to record parameters of batch normalization(2019/1/7)
                weights.append(copy.deepcopy(self.model.bn1.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn1.beta.data))
                weights.append(copy.deepcopy(self.model.bn2.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn2.beta.data))
                weights.append(copy.deepcopy(self.model.bn3.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn3.beta.data))
                weights.append(copy.deepcopy(self.model.bn4.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn4.beta.data))
                self.controllers.append(copy.deepcopy(weights))

        else:
            for i in range(0,self.num_of_controller):
                with open(model, 'rb') as i:
                    self.model = pickle.load(i)
                    self.data_size = 0

                if self.use_gpu >= 0:
                    chainer.backends.cuda.get_device_from_id(self.use_gpu).use()
                    self.model.to_gpu()

                weights=[]
                weights.append(copy.deepcopy(self.model.conv1.W.data))
                weights.append(copy.deepcopy(self.model.conv2.W.data))
                weights.append(copy.deepcopy(self.model.conv3.W.data))
                weights.append(copy.deepcopy(self.model.conv4.W.data))
                weights.append(copy.deepcopy(self.model.l1.W.data))
                weights.append(copy.deepcopy(self.model.q_value.W.data))   
                weights.append(copy.deepcopy(self.model.bn1.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn1.beta.data))
                weights.append(copy.deepcopy(self.model.bn2.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn2.beta.data))
                weights.append(copy.deepcopy(self.model.bn3.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn3.beta.data))
                weights.append(copy.deepcopy(self.model.bn4.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn4.beta.data))                     
                self.controllers.append(copy.deepcopy(weights))

        #this part was add by morimoto(2018/11/16) to arragne initial parameters
        if initial != 'None':
            for i in range(0,self.num_of_controller):
                with open(initial, 'rb') as I:
                    self.model = pickle.load(I)

                if self.use_gpu >= 0:
                    chainer.backends.cuda.get_device_from_id(self.use_gpu).use()
                    self.model.to_gpu()
                
                weights=[]
                weights.append(copy.deepcopy(self.model.conv1.W.data))
                weights.append(copy.deepcopy(self.model.conv2.W.data))
                weights.append(copy.deepcopy(self.model.conv3.W.data))
                weights.append(copy.deepcopy(self.model.conv4.W.data))
                weights.append(copy.deepcopy(self.model.l1.W.data))
                weights.append(copy.deepcopy(self.model.q_value.W.data))    
                weights.append(copy.deepcopy(self.model.bn1.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn1.beta.data))
                weights.append(copy.deepcopy(self.model.bn2.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn2.beta.data))
                weights.append(copy.deepcopy(self.model.bn3.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn3.beta.data))
                weights.append(copy.deepcopy(self.model.bn4.gamma.data))   
                weights.append(copy.deepcopy(self.model.bn4.beta.data))                    
                self.controllers.append(copy.deepcopy(weights))

        print (self.controllers[0][0][0][0][0] )
       
        #this part was add by morimoto(2018/11/25)
        self.temp_best_weights.append(copy.deepcopy(self.model.conv1.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.conv2.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.conv3.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.conv4.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.l1.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.q_value.W.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.bn1.gamma.data))   
        self.temp_best_weights.append(copy.deepcopy(self.model.bn1.beta.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.bn2.gamma.data))   
        self.temp_best_weights.append(copy.deepcopy(self.model.bn2.beta.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.bn3.gamma.data))   
        self.temp_best_weights.append(copy.deepcopy(self.model.bn3.beta.data))
        self.temp_best_weights.append(copy.deepcopy(self.model.bn4.gamma.data))   
        self.temp_best_weights.append(copy.deepcopy(self.model.bn4.beta.data))

        self.optimizer = optimizers.RMSpropGraves()
        self.optimizer.setup(self.model)

        self.datas=[]
        # History Data :  D=[s, a, r, s_dash, end_episode_flag]

        if self.evolution !=3 or self.log!=0: #neuro evolution does'nt use experience
            for i in range(0,self.num_of_controller):
                self.d = [np.zeros((self.agent_count, self.data_size, self.hist_size, 128, 128, 3), dtype=np.uint8),
                          np.zeros((self.agent_count, self.data_size, self.hist_size, self.other_input_dim), dtype=np.uint8),
                          np.zeros((self.agent_count, self.data_size), dtype=np.uint8),
                          np.zeros((self.agent_count, self.data_size, 1), dtype=np.float32),
                          np.zeros((self.agent_count, self.data_size, 1), dtype=np.bool)]#replay buffer add by Louis 2019.8.1
                self.datas.append(copy.deepcopy(self.d))

        self.q_log = self.logDirPath + "q.log"
        self.loss_log = self.logDirPath + "loss.log"

        print ("finish initialize")

    def _reshape_for_cnn(self, state, batch_size, hist_size, x, y):
        
        state_ = np.zeros((batch_size, 3 * hist_size , 128, 128), dtype=np.float32)
        for i in range(batch_size):
            if self.hist_size == 1 :
                state_[i] = state[i][0].transpose(2, 0, 1)
            elif self.hist_size == 2:
                state_[i] = np.c_[state[i][0], state[i][1]].transpose(2, 0, 1)
            elif self.hist_size == 4:
                state_[i] = np.c_[state[i][0], state[i][1], state[i][2], state[i][3]].transpose(2, 0, 1)
        
        return  state_

    def forward(self, state_cnn, state_other, action, reward,
                state_cnn_dash, state_other_dash, episode_end,controller_id):
        
        num_of_batch = state_cnn.shape[0]
        s_cnn = Variable(state_cnn)
        s_oth = Variable(state_other)
        s_cnn_dash = Variable(state_cnn_dash)
        s_oth_dash = Variable(state_other_dash)

        q = self.q_func(s_cnn, s_oth, controller_id)  # Get Q-value
        
        max_q_dash_ = self.q_func(s_cnn_dash, s_oth_dash,controller_id)
        if self.use_gpu >= 0:
            tmp = list(map(np.max, max_q_dash_.data.get()))
        else:
            tmp = list(map(np.max, max_q_dash_.data))
        max_q_dash = np.asanyarray(tmp, dtype=np.float32)
        if self.use_gpu >= 0:
            target = np.array(q.data.get(), dtype=np.float32)
        else:
            target = np.array(q.data, dtype=np.float32)

        for i in range(num_of_batch):
            tmp_ = reward[i] + (1 - episode_end[i]) * self.gamma * max_q_dash[i]

            action_index = self.action_to_index(action[i])
            target[i, action_index] = tmp_
        
        if self.use_gpu >= 0:
            loss = F.mean_squared_error(Variable(cuda.to_gpu(target)), q)
        else:
            loss = F.mean_squared_error(Variable(target), q)
        
        return loss, q

    def stock_experience(self, time,
                        state_cnn, state_other, action, reward,
                        state_cnn_dash, state_other_dash, episode_end_flag,controller_id):

        for i in range(self.agent_count):
            self.datas[controller_id][0][i][self.data_index[controller_id]] = state_cnn[i].copy()
            self.datas[controller_id][1][i][self.data_index[controller_id]] = state_other[i].copy()
            self.datas[controller_id][2][i][self.data_index[controller_id]] = action[i].copy()
            self.datas[controller_id][3][i][self.data_index[controller_id]] = reward[i].copy()
            self.datas[controller_id] [4][i][self.data_index[controller_id]] = episode_end_flag
                
        self.data_index[controller_id] += 1
        if self.data_index[controller_id] >= self.data_size:
            self.data_index[controller_id] -= self.data_size
            self.data_flag[controller_id] = True

    def experience_replay(self, time,controller_id):
        if self.initial_exploration < time:
            # Pick up replay_size number of samples from the Data
            replayRobotIndex = np.random.randint(0, self.agent_count, self.replay_size)
            if not self.data_flag[controller_id]:  # during the first sweep of the History Data
                replay_index = np.random.randint(0, self.data_index[controller_id], self.replay_size)
            else:
                replay_index = np.random.randint(0, self.data_size, self.replay_size)

            s_cnn_replay = np.ndarray(shape=(self.replay_size, self.hist_size, 128, 128, 3), dtype=np.float32)
            s_oth_replay = np.ndarray(shape=(self.replay_size, self.hist_size, self.other_input_dim), dtype=np.float32)
            a_replay = np.ndarray(shape=(self.replay_size, 1), dtype=np.uint8)
            r_replay = np.ndarray(shape=(self.replay_size, 1), dtype=np.float32)
            s_cnn_dash_replay = np.ndarray(shape=(self.replay_size, self.hist_size, 128, 128, 3), dtype=np.float32)
            s_oth_dash_replay = np.ndarray(shape=(self.replay_size, self.hist_size, self.other_input_dim), dtype=np.float32)
            episode_end_replay = np.ndarray(shape=(self.replay_size, 1), dtype=np.bool)
                
            for i in range(self.replay_size):
                s_cnn_replay[i] = np.asarray((self.datas[controller_id][0][replayRobotIndex[i]][replay_index[i]]), dtype=np.float32)
                s_oth_replay[i] = np.asarray((self.datas[controller_id][1][replayRobotIndex[i]][replay_index[i]]), dtype=np.float32)
                a_replay[i] = self.datas[controller_id][2][replayRobotIndex[i]][replay_index[i]]
                r_replay[i] = self.datas[controller_id][3][replayRobotIndex[i]][replay_index[i]]
                if (replay_index[i] + 1 >= self.data_size):
                    s_cnn_dash_replay[i] = np.array((self.datas[controller_id][0][replayRobotIndex[i]][replay_index[i] + 1 - self.data_size]), dtype=np.float32)
                    s_oth_dash_replay[i] = np.array((self.datas[controller_id][1][replayRobotIndex[i]][replay_index[i] + 1 - self.data_size]), dtype=np.float32)
                else:
                    s_cnn_dash_replay[i] = np.array((self.datas[controller_id][0][replayRobotIndex[i]][replay_index[i] + 1]), dtype=np.float32)
                    s_oth_dash_replay[i] = np.array((self.datas[controller_id][1][replayRobotIndex[i]][replay_index[i] + 1]), dtype=np.float32)
                episode_end_replay[i] = self.datas[controller_id][4][replayRobotIndex[i]][replay_index[i]]
    
            s_cnn_replay = self._reshape_for_cnn(s_cnn_replay, self.replay_size,
                                                 self.hist_size, 128, 128)
            s_cnn_dash_replay = self._reshape_for_cnn(s_cnn_dash_replay, self.replay_size,
                                                 self.hist_size, 128, 128)
                
            s_cnn_replay /= 255.0
            s_oth_replay /= 255.0
            s_cnn_dash_replay /= 255.0
            s_oth_dash_replay /= 255.0
    
            if self.use_gpu >= 0:
                s_cnn_replay = cuda.to_gpu(s_cnn_replay)
                s_oth_replay = cuda.to_gpu(s_oth_replay)
                s_cnn_dash_replay = cuda.to_gpu(s_cnn_dash_replay)
                s_oth_dash_replay = cuda.to_gpu(s_oth_dash_replay)

            # Gradient-based update
            loss, _ = self.forward(s_cnn_replay, s_oth_replay, a_replay, r_replay,
                                       s_cnn_dash_replay, s_oth_dash_replay,
                                       episode_end_replay,controller_id)

            if self.log!=0:
                with open(self.loss_log, 'a') as the_file:
                    the_file.write(str(loss.data))
                    the_file.write('\n')

            if self.evolution!=3:
                #print loss
                #self.optimizer.zero_grads()
                #print self.model.conv1.W[0][0][0][0]
                #print "controller_id",controller_id,"before_bp",self.model.conv1.W.data[0][0][0][0]
                #print "before learning",self.model.conv1.W.data[0][0][0][0]
                self.model.cleargrads()
                loss.backward()
                self.optimizer.update()
                #print "controller_id",controller_id,"after_bp ",self.model.conv1.W.data[0][0][0][0]
                #print " "
                #print "after learning",self.model.conv1.W.data[0][0][0][0]
                self.get_weights(controller_id) 
                #print "get_weights",self.controllers[controller_id][0][0][0][0]

    def test(self,loss):

        #loss = F.mean_squared_error(Variable(a), Variable(b))
        #self.optimizer.zero_grads()
        #print self.model.conv1.W[0][0][0][0]

        self.controllers[0].cleargrads()
        loss.backward()
        print ("self.optimizers",self.optimizers)
        self.optimizers[0].update()


    def q_func(self, state_cnn, state_other, controller_id):

        #print(type(cuda.to_cpu(state_other.data)))
        #print(cuda.to_cpu(state_other.data).shape)
        #print(cuda.to_cpu(state_other.data)[0][0])



        self.set_weights(controller_id) 
 
        if self.use_gpu >= 0:
            num_of_batch = state_cnn.data.get().shape[0]
        else:
            num_of_batch = state_cnn.data.shape[0]

        h1 = F.tanh(self.model.bn1(self.model.conv1(state_cnn)))
        #print("h1 shape",cuda.to_cpu(h1.data).shape)
        h2 = F.tanh(self.model.bn2(self.model.conv2(h1)))
        #print("h2 shape",cuda.to_cpu(h2.data).shape)
        h3 = F.tanh(self.model.bn3(self.model.conv3(h2)))
        #print("h3 shape",cuda.to_cpu(h3.data).shape)
        h4 = F.tanh(self.model.bn4(self.model.conv4(h3)))
#         h5 = F.tanh(self.model.bn5(self.model.conv5(h4)))
        #print("h4 shape",cuda.to_cpu(h4.data).shape)
        #print("num_of_batch",num_of_batch)
        #print("self.feature_dim",self.feature_dim)
        #print("state_other",cuda.to_cpu(state_other.data).shape)
        #print("self.other_input_dim",self.other_input_dim)
        #print("self.hist_size",self.hist_size)

        h4_ = F.concat((F.reshape(h4, (num_of_batch, self.feature_dim)),
                        F.reshape(state_other, (num_of_batch, self.other_input_dim * self.hist_size))), axis=1)
        
        h6 = F.relu(self.model.l1(h4_))
        q = F.tanh(self.model.q_value(h6))
        #print ("q",q)
        #q = self.model.q_value(h6) //edit in 19.11.21 for continuous

        return q

    def e_greedy(self, state_cnn, state_other, epsilon, reward, controller_id):
        s_cnn = Variable(state_cnn)
        s_oth = Variable(state_other)
        q = self.q_func(s_cnn, s_oth, controller_id)

        q = q.data        
 
        with open(self.q_log, 'a') as the_file:
            the_file.write(str(q))
            the_file.write('\n')

        if self.use_gpu >= 0: 
            q_ = q.get()
        else:
            q_ = q

        index_action = np.zeros((self.agent_count), dtype=np.uint8)
        '''
        #print("agent"),
        for i in range(self.agent_count):
            if np.random.rand() < epsilon:
                index_action[i] = np.random.randint(0, self.num_of_actions)
                #print("[%02d] Randam(%2d)reward(%06.2f)" % (i, index_action[i], reward[i])),
            else:
                index_action[i] = np.argmax(q_[i])
                #print("[%02d]!Greedy(%2d)reward(%06.2f)" % (i, index_action[i], reward[i])),
        
        del q_
        #print index_action
        return self.index_to_action(index_action), q
        '''
        return q_

    def index_to_action(self, index_of_action):
        index = np.zeros((self.agent_count), dtype=np.uint8)
        for i in range(self.agent_count):
            index[i] = self.enable_controller[index_of_action[i]]
        return index

    def action_to_index(self, action):
        return self.enable_controller.index(action)

    
    #save the weights of ANN in the first time of each episode
    def record_model(self, controller_id): #this functijon add by morimoto(2018/10/30)
        print ("record_",controller_id,"controller")

        self.weights_in_first_of_episode=[]
        for i in range(0,len(self.controllers[controller_id])):
            self.weights_in_first_of_episode.append(copy.deepcopy(self.controllers[controller_id][i]))
        #update list 
        self.list_for_weights_in_first_of_episode[controller_id]=copy.deepcopy(self.weights_in_first_of_episode)


    def temp_best_back_to_first_of_episode(self,controller_id): #this functijon add by morimoto(2018/11/15), used by baldwin mode and evolution
        for i in range(0,len(self.list_for_weights_in_first_of_episode[controller_id])):
            self.temp_best_weights[i]=copy.deepcopy(self.list_for_weights_in_first_of_episode[controller_id][i])   
 

    def save_model(self,controller_id): #this functijon add by morimoto(2018/11/15)
        for i in range(0,len(self.controllers[controller_id])):
            self.temp_best_weights[i]=copy.deepcopy(self.controllers[controller_id][i])
          

    def set_weights(self,controller_id):
        self.model.conv1.W.data=copy.deepcopy(self.controllers[controller_id][0])
        self.model.conv2.W.data=copy.deepcopy(self.controllers[controller_id][1])
        self.model.conv3.W.data=copy.deepcopy(self.controllers[controller_id][2])
        self.model.conv4.W.data=copy.deepcopy(self.controllers[controller_id][3])
        self.model.l1.W.data=copy.deepcopy(self.controllers[controller_id][4])
        self.model.q_value.W.data=copy.deepcopy(self.controllers[controller_id][5])
        #BN parameters
        self.model.bn1.gamma.data=copy.deepcopy(self.controllers[controller_id][6])
        self.model.bn1.beta.data=copy.deepcopy(self.controllers[controller_id][7])
        self.model.bn2.gamma.data=copy.deepcopy(self.controllers[controller_id][8])
        self.model.bn2.beta.data=copy.deepcopy(self.controllers[controller_id][9])
        self.model.bn3.gamma.data=copy.deepcopy(self.controllers[controller_id][10])
        self.model.bn3.beta.data=copy.deepcopy(self.controllers[controller_id][11])
        self.model.bn4.gamma.data=copy.deepcopy(self.controllers[controller_id][12])
        self.model.bn4.beta.data=copy.deepcopy(self.controllers[controller_id][13])

    def get_weights(self,controller_id):
        self.controllers[controller_id][0]=copy.deepcopy(self.model.conv1.W.data)
        self.controllers[controller_id][1]=copy.deepcopy(self.model.conv2.W.data)
        self.controllers[controller_id][2]=copy.deepcopy(self.model.conv3.W.data)
        self.controllers[controller_id][3]=copy.deepcopy(self.model.conv4.W.data)
        self.controllers[controller_id][4]=copy.deepcopy(self.model.l1.W.data)
        self.controllers[controller_id][5]=copy.deepcopy(self.model.q_value.W.data)
        #BN parameters
        self.controllers[controller_id][6]=copy.deepcopy(self.model.bn1.gamma.data)
        self.controllers[controller_id][7]=copy.deepcopy(self.model.bn1.beta.data)
        self.controllers[controller_id][8]=copy.deepcopy(self.model.bn2.gamma.data)
        self.controllers[controller_id][9]=copy.deepcopy(self.model.bn2.beta.data)
        self.controllers[controller_id][10]=copy.deepcopy(self.model.bn3.gamma.data)
        self.controllers[controller_id][11]=copy.deepcopy(self.model.bn3.beta.data)
        self.controllers[controller_id][12]=copy.deepcopy(self.model.bn4.gamma.data)
        self.controllers[controller_id][13]=copy.deepcopy(self.model.bn4.beta.data)

    def set_temp_best(self):
        self.model.conv1.W.data=copy.deepcopy(self.temp_best_weights[0])
        self.model.conv2.W.data=copy.deepcopy(self.temp_best_weights[1])
        self.model.conv3.W.data=copy.deepcopy(self.temp_best_weights[2])
        self.model.conv4.W.data=copy.deepcopy(self.temp_best_weights[3])
        self.model.l1.W.data=copy.deepcopy(self.temp_best_weights[4])
        self.model.q_value.W.data=copy.deepcopy(self.temp_best_weights[5])
        #BN parameters
        self.model.bn1.gamma.data=copy.deepcopy(self.temp_best_weights[6])
        self.model.bn1.beta.data=copy.deepcopy(self.temp_best_weights[7])
        self.model.bn2.gamma.data=copy.deepcopy(self.temp_best_weights[8])
        self.model.bn2.beta.data=copy.deepcopy(self.temp_best_weights[9])
        self.model.bn3.gamma.data=copy.deepcopy(self.temp_best_weights[10])
        self.model.bn3.beta.data=copy.deepcopy(self.temp_best_weights[11])
        self.model.bn4.gamma.data=copy.deepcopy(self.temp_best_weights[12])
        self.model.bn4.beta.data=copy.deepcopy(self.temp_best_weights[13])


    def evolve_model(self, size,rank,fitness,comm,algorithm,evolution): #this functijon add by morimoto(2018/10/22) evolve the controller

        self.size=size
        self.rank=rank

        if algorithm==0:  # simple GA
            # 1st:gathering rewards and comparing, decide the elite controller 
            self.total_rewards_in_episode = comm.gather([total_reward_in_episode,rank],root=0)  #gather rewards and ranks of each machine
            self.elite_id=0
            self.elite_rank=0
 
            print ("self.total_rewards_in_episode",self.total_rewards_in_episode)
            #master node find the rank of the machine retaining a elite controller
            if rank==0:
                self.elite=self.total_rewards_in_episode[0][0]
                self.elite_rank=self.total_rewards_in_episode[0][1]

                for i in range(0,size):
                    if self.elite<self.total_rewards_in_episode[i][0]:
                        self.elite=self.total_rewards_in_episode[i][0]
                        self.elite_rank=self.total_rewards_in_episode[i][1]
            self.elite_id = comm.bcast(self.elite_rank, root=0)       # scattering elite_id to all machines
            print ("self.elite_id:",self.elite_id)

            # 2nd:get the weight of neural network
            self.weights_of_CNN = []
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv1.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv2.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv3.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv4.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.l1.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.q_value.W.data))
        
            self.weights_of_CNN = comm.bcast(self.weights_of_CNN, root=self.elite_id)

            print ("rank:",rank,",before perturbation",self.model.conv1.W.data[0][0][0][0])    
            if rank!=self.elite_id:    #only elite controller survive to next generation and other machine's controller will be mutated
                self.evolution_algorithm(self.weights_of_CNN,self.size,self.rank,algorithm)
            print ("rank:",rank,",after  perturbation",self.model.conv1.W.data[0][0][0][0])     



        if algorithm==1:  # DE(Differencial Evolution)
       
            s_time=time.time()
            # 1st:make a set of weight and reward
            self.w_and_r=[]
            #self.w_and_r_list=[]
           
            #get weights of CNN
            self.weights_of_CNN = []
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv1.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv2.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv3.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.conv4.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.l1.W.data))
            self.weights_of_CNN.append(copy.deepcopy(self.model.q_value.W.data))

            #make a set 
            self.w_and_r.append(self.weights_of_CNN)
            self.w_and_r.append(total_reward_in_episode)
            self.w_and_r.append(rank)
            self.w_and_r_list = comm.gather(self.w_and_r,root=0)  #gather rewards and ranks of each machine

            #broadcat to all machines
            self.w_and_r_list = comm.bcast(self.w_and_r_list, root=0)
            

            print ("rank:",rank,",before DE",self.model.conv1.W.data[0][0][0][0])       
            #evolve the weights of CNN
            self.evolution_algorithm(self.w_and_r_list,self.size,self.rank,algorithm)
            print ("rank:",rank,",after  DE",self.model.conv1.W.data[0][0][0][0])  
            
            f_time=time.time()
            print ("total",f_time - s_time)


        if algorithm==2:  # more mild GA
            self.total_rewards_in_episode = comm.gather([total_reward_in_episode,rank],root=0)  #gather rewards and ranks 
            self.f_st_elite_rank=0
            self.s_nd_elite_rank=0
            self.th_rd_elite_rank=0
            self.elite_ids=[]

            #master node find the rank of the machine retaining a elite controller
            if rank==0:

                print (self.total_rewards_in_episode)
                #find first elite
                self.elite=self.total_rewards_in_episode[0][0]
                self.f_st_elite_rank=self.total_rewards_in_episode[0][1]
                self.id=0
                for i in range(0,size):
                    if self.elite<self.total_rewards_in_episode[i][0]:
                        self.elite=self.total_rewards_in_episode[i][0]
                        self.f_st_elite_rank=self.total_rewards_in_episode[i][1]
                        self.id=i
                del self.total_rewards_in_episode[self.id]
                self.elite_ids.append(self.f_st_elite_rank)

                #find second elite
                self.elite=self.total_rewards_in_episode[0][0]
                self.s_nd_elite_rank=self.total_rewards_in_episode[0][1]
                self.id=0
                for i in range(0,size-1):
                    if self.elite<self.total_rewards_in_episode[i][0]:
                        self.elite=self.total_rewards_in_episode[i][0]
                        self.s_nd_elite_rank=self.total_rewards_in_episode[i][1]
                        self.id=i
                del self.total_rewards_in_episode[self.id]
                self.elite_ids.append(self.s_nd_elite_rank)

                
                #fine third elite
                self.elite=self.total_rewards_in_episode[0][0]
                self.th_rd_elite_rank=self.total_rewards_in_episode[0][1]
                self.id=0
                for i in range(0,size-2):
                    if self.elite<self.total_rewards_in_episode[i][0]:
                        self.elite=self.total_rewards_in_episode[i][0]
                        self.th_rd_elite_rank=self.total_rewards_in_episode[i][1]
                del self.total_rewards_in_episode
                self.elite_ids.append(self.th_rd_elite_rank)

                

            self.elite_ids = comm.bcast(self.elite_ids, root=0)       # scattering elite_id to all machines

            print (self.elite_ids)

            #use the initial weights of episode if mode is baldwin effect
            if evolution==2 or evolution==3:
                self.weights_of_CNN = copy.deepcopy(self.weights_in_first_of_episode)
            
            else:
                #get weights of CNN
                self.weights_of_CNN = []
                self.weights_of_CNN.append(copy.deepcopy(self.model.conv1.W.data))
                self.weights_of_CNN.append(copy.deepcopy(self.model.conv2.W.data))
                self.weights_of_CNN.append(copy.deepcopy(self.model.conv3.W.data))
                self.weights_of_CNN.append(copy.deepcopy(self.model.conv4.W.data))
                self.weights_of_CNN.append(copy.deepcopy(self.model.l1.W.data))
                self.weights_of_CNN.append(copy.deepcopy(self.model.q_value.W.data))

            # 1st:make a list of weight and rank
            self.w_and_r=[]
            self.w_and_r.append(self.weights_of_CNN)
            self.w_and_r.append(self.elite_ids)

            self.w_and_r_list = comm.gather(self.w_and_r,root=0)  #gather rewards and ranks of each machine

            #broadcat to all machines
            self.w_and_r_list = comm.bcast(self.w_and_r_list, root=0)

            print ("rank:",rank,",before m_GA",self.model.conv1.W.data[0][0][0][0])       
            #evolve the weights of CNN
            self.evolution_algorithm(self.w_and_r_list,self.size,self.rank,algorithm)
            print ("rank:",rank,",after  m_GA",self.model.conv1.W.data[0][0][0][0])  


        if algorithm==3:  #tournament GA
            self.parents=[0]*(self.size*self.num_of_controller)
            self.controller_list=[0]*(self.size*self.num_of_controller)
            self.total_fitness = comm.gather([fitness,rank],root=0)  #gather rewards and ranks 
            if rank==0:
                #reshape         
                for i in range(0,size):
                    for j in range(0,self.num_of_controller):
                        self.controller_list[i*self.num_of_controller+j]=[self.total_fitness[i][0][j],self.total_fitness[i][1]]  #self.controller_list=[[[arrival,reward],rank],...,[[arrival,reward],rank]]
                print ("self.controller_list",self.controller_list)
                #select next parents by tournament 
                parent_id_list=[]
                for i in range(0,self.size*self.num_of_controller): #make list for selection
                    parent_id_list.append(i)


                '''
                #compare only distance
                for i in range(0,self.size*self.num_of_controller):
                    if i==0: #elite regeneration
                        a=0
                        temp=self.controller_list[a][0][0]
                        for j in range(1,size*self.num_of_controller):
                            if temp<self.controller_list[j][0][0]:
                                a=j
                                temp=self.controller_list[j][0][0]
                        self.parents[i]=copy.deepcopy([a,self.controller_list[a][1]])

                    else:   #select remaining parents
                        parent_candi=random.sample(parent_id_list,self.selection_number)
                        a=parent_candi[0]
                        temp=self.controller_list[a][0][0]
                        for j in range(1,self.selection_number):
                            b=parent_candi[j]
                            if temp<self.controller_list[b][0][0]:
                                a=b
                                temp=self.controller_list[b][0][0]
                        self.parents[i]=copy.deepcopy([a,self.controller_list[a][1]])

                '''
                #compare reward in DRL
                for i in range(0,self.size*self.num_of_controller):
                    if i==0: #elite regeneration
                        a=0
                        temp=self.controller_list[a][0][1]
                        for j in range(1,size*self.num_of_controller):
                            if temp<self.controller_list[j][0][1]:
                                a=j
                                temp=self.controller_list[j][0][1]
                        self.parents[i]=copy.deepcopy([a,self.controller_list[a][1]])

                    else:   #select remaining parents
                        parent_candi=random.sample(parent_id_list,self.selection_number)
                        a=parent_candi[0]
                        temp=self.controller_list[a][0][1]
                        for j in range(1,self.selection_number):
                            b=parent_candi[j]
                            if temp<self.controller_list[b][0][1]:
                                a=b
                                temp=self.controller_list[b][0][1]
                        self.parents[i]=copy.deepcopy([a,self.controller_list[a][1]])
                #'''

            #broadcast the result of parents selection
            self.parents = comm.bcast(self.parents, root=0)
            self.list_for_weights_of_CNN=[0]*self.num_of_controller   #each machine prepare list of controller's weights
            for i in range(0,self.num_of_controller):

                if evolution==2 or evolution==3: #use weights in first of epsode for 2:baldwin and 3:only_evolution
                    self.weights_of_CNN=[]
                    self.weights_of_CNN = copy.deepcopy(self.list_for_weights_in_first_of_episode[i])
                    self.list_for_weights_of_CNN[i]=copy.deepcopy(self.weights_of_CNN)
 
                else:                            #use trained weights for 1:Lamarckism
                    self.list_for_weights_of_CNN[i]=copy.deepcopy(self.controllers[i])

            #each machine get the next parents weights
            self.parents_weight=[0]*self.num_of_controller
            for i in range(0,self.size*self.num_of_controller):

                #if have a parent in own side, there are no need to comunicate
                if i/self.num_of_controller==self.rank and self.parents[i][1]==self.rank:
                    self.parents_weight[i%self.num_of_controller]=copy.deepcopy(self.list_for_weights_of_CNN[self.parents[i][0]%self.num_of_controller])

                #comunicate with other machine (or own) and get weights
                elif i/self.num_of_controller==self.rank or self.parents[i][1]==self.rank:
                    sender_rank=self.parents[i][1]
                    receiver_rank=i/self.num_of_controller

                    #holder of parent weights send the weights to receiver
                    if self.rank==sender_rank:      
                        comm.send(self.list_for_weights_of_CNN[self.parents[i][0]%self.num_of_controller], dest=receiver_rank, tag=11)
                    #recever gets weights from holder
                    elif self.rank==receiver_rank:   
                        self.parents_weight[i%self.num_of_controller]=comm.recv(source=sender_rank, tag=11)

            print ("self.parents",self.parents)
            print ("rank:",rank,",before t_GA",self.controllers[0][12][0])
            print ("rank:",rank,",before t_GA",self.controllers[0][0][0][0][0])
            #evolve the weights of CNN
            self.evolution_algorithm(self.parents_weight,self.size,self.rank,algorithm)
            print ("rank:",rank,",after  t_GA",self.controllers[0][12][0])  
            print ("rank:",rank,",after  t_GA",self.controllers[0][0][0][0][0])  
               

        if algorithm==4:  #(mu,lambda)-ES
            self.parents=[0]*(self.size*self.num_of_controller)
            self.controller_list=[0]*(self.size*self.num_of_controller)
            self.total_fitness_and_weights = comm.gather([fitness,rank,self.controllers],root=0)  #gather rewards and ranks 
            self.elite_id=0
            self.elite_weights=[]
            self.parents_weight=[0]*self.mu
            self.after_weight=[0]*self.lambda_
            self.pop=[0]*self.mu
            #self.pop=cuda.to_gpu(np.array(self.pop))

            print ("rank:",rank,",before  (m,l)-ES",self.controllers[0][0][0][0][0])
            if rank==0:
                #reshape         
                for i in range(0,size):
                    for j in range(0,self.num_of_controller):
                        self.controller_list[i*self.num_of_controller+j]=[self.total_fitness_and_weights[i][0][j],
                        self.total_fitness_and_weights[i][1],self.total_fitness_and_weights[i][2][j]] 
#self.controller_list=[[[arrival,reward],rank,[self.controllers[?]]],...,[[arrival,reward],rank,self.controllers[?]]] 0~39
                
                print ("self.controller_list",len(self.controller_list))
                #select next parents by tournament 
                parent_id_list=[]

                for i in range(0,self.mu): #make list for selection
                    parent_id_list.append(i)

                for i in range(0,self.mu+1):
                    if i==0: #elite regeneration
                        a=0
                        temp=self.controller_list[a][0][0]
                        for j in range(1,size*self.num_of_controller):
                            if temp<self.controller_list[j][0][0]:
                                a=j
                                temp=self.controller_list[j][0][0]
                        self.elite_weights = copy.deepcopy(self.controller_list[a][2])

                    else:   #select remaining parents
                        parent_candi=random.sample(parent_id_list,self.selection_number)
                        a=parent_candi[0]
                        temp=self.controller_list[a][0][0]
                        for j in range(1,self.selection_number):
                            b=parent_candi[j]
                            if temp<self.controller_list[b][0][0]:
                                a=b
                                temp=self.controller_list[b][0][0]
                        self.parents_weight[i-1]=copy.deepcopy(self.controller_list[a][2])
                        #self.parent = (--- [[24,4],[16,3],...,[controller_No.,rank],...,[3,1]])

                #reshape for ES

                for i in range(0,self.mu):
                    for j in range(0,len(self.parents_weight[0])):
                        temp = copy.deepcopy(cuda.to_cpu(self.parents_weight[i][j]).reshape(-1))
                        if j ==0:
                            self.pop[i] = copy.deepcopy(temp)
                        else:
                            temp2=copy.deepcopy(self.pop[i])
                            temp3 = np.hstack((temp, temp2))
                            self.pop[i] = copy.deepcopy(temp3)
                    self.pop[i]=self.pop[i].tolist()

                print ("reshape",len(self.pop[0]))
                
                #preparing for ES
                IND_SIZE = len(self.pop[0])
                MIN_VALUE = 0
                MAX_VALUE = 0
                MIN_STRATEGY = 0
                MAX_STRATEGY = 1

                creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
                creator.create("Individual", array.array, typecode="d", fitness=creator.FitnessMin, strategy=None)
                creator.create("Strategy", array.array, typecode="d")

                # Individual generator
                def generateES(icls, scls, size, imin, imax, smin, smax):
                    ind = icls(random.uniform(imin, imax) for _ in range(size))
                    ind.strategy = scls(random.uniform(smin, smax) for _ in range(size))
                    return ind

                def checkStrategy(minstrategy):
                    def decorator(func):
                        def wrappper(*args, **kargs):
                            children = func(*args, **kargs)
                            for child in children:
                                for i, s in enumerate(child.strategy):
                                    if s < minstrategy:
                                        child.strategy[i] = minstrategy
                            return children
                        return wrappper
                    return decorator

                toolbox = base.Toolbox()
                toolbox.register("individual", generateES, creator.Individual, creator.Strategy,
                    IND_SIZE, MIN_VALUE, MAX_VALUE, MIN_STRATEGY, MAX_STRATEGY)
                toolbox.register("population", tools.initRepeat, list, toolbox.individual)
                toolbox.register("mate", tools.cxESBlend, alpha=0.1)
                toolbox.register("mutate", tools.mutESLogNormal, c=1.0, indpb=1)
                toolbox.register("select", tools.selTournament, tournsize=2)
                toolbox.register("evaluate", benchmarks.sphere)

                toolbox.decorate("mate", checkStrategy(MIN_STRATEGY))
                toolbox.decorate("mutate", checkStrategy(MIN_STRATEGY))

                MU, LAMBDA = self.mu, self.lambda_
                pop2 = toolbox.population(n=MU)

                #copy to pop
                for i in range(0,len(self.pop)):
                    for j in range(0,len(self.pop[0])):
                        pop2[i][j]=self.pop[i][j]


                #ES-engine
                pop2=algorithms.varOr(pop2, toolbox, lambda_=LAMBDA, cxpb=0, mutpb=1)
                
                print ("after")
                #re-copy
                self.pop=copy.deepcopy(np.array(pop2))

                #re-store updated weights
                st_pos=0
                dest_pos=0
                temp2=[0]*len(self.controllers[0])
                for i in range(0,self.lambda_):
                    for j in range(0,len(self.controllers[0])):
                        #slice the long 1D weights
                        if j==0:
                            dest_pos=len(self.controllers[0][j].reshape(-1))
                            temp=copy.deepcopy(self.pop[i][0:dest_pos])
                            st_pos=dest_pos
                        else:
                            dest_pos=st_pos+len(self.controllers[0][j].reshape(-1))
                            temp=copy.deepcopy(self.pop[i][st_pos:dest_pos])
                            st_pos=dest_pos
                        temp2[j]=copy.deepcopy(temp.reshape(np.shape(self.controllers[0][j])))
                    self.after_weight[i]=copy.deepcopy(temp2)

            #rank 0 broadcast the results
            self.after_weight = comm.bcast(self.after_weight, root=0)

            #set weights
            for i in range(0,self.num_of_controller):
                if i==0 and self.rank==0: #elite regeneration
                    self.controllers[i]=copy.deepcopy(cuda.to_gpu(self.elite_weights))

                else:
                    self.controllers[i]=copy.deepcopy(cuda.to_gpu(self.after_weight[self.rank*self.num_of_controller+i]))
            print ("rank:",rank,",after  (m,l)-ES",self.controllers[0][0][0][0][0])  



    def evolution_algorithm(self, weights_of_CNN,size,rank,algorithm):
        #make a next generation by some algorithms


        if algorithm==0: #(simple GA from Deep-Neuroevolution)
            mutation_power=0.02
            new_weights=[]

            #first convolutional layer
            temp = weights_of_CNN[0].reshape(-1)      
            noise = copy.deepcopy(self.model.conv1.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.conv1.W.data))   #reshape renewaled parameter to original shape
            self.model.conv1.W.data=copy.deepcopy(temp)

            #second convolutional layer
            temp = weights_of_CNN[1].reshape(-1)      
            noise = copy.deepcopy(self.model.conv2.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.conv2.W.data))   #reshape renewaled parameter to original shape
            self.model.conv2.W.data=copy.deepcopy(temp)

            #third convolutional layer
            temp = weights_of_CNN[2].reshape(-1)      
            noise = copy.deepcopy(self.model.conv3.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.conv3.W.data))   #reshape renewaled parameter to original shape
            self.model.conv3.W.data=copy.deepcopy(temp)

            #fourth convolutional layer
            temp = weights_of_CNN[3].reshape(-1)      
            noise = copy.deepcopy(self.model.conv4.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.conv4.W.data))   #reshape renewaled parameter to original shape
            self.model.conv4.W.data=copy.deepcopy(temp)

            #first dense layer
            temp = weights_of_CNN[4].reshape(-1)      
            noise = copy.deepcopy(self.model.l1.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.l1.W.data))   #reshape renewaled parameter to original shape
            self.model.l1.W.data=copy.deepcopy(temp)

            #output layer
            temp = weights_of_CNN[5].reshape(-1)      
            noise = copy.deepcopy(self.model.q_value.W.data).reshape(-1)   #noise is 1 dim array 
            for j in range(0,len(noise)):
                noise[j]=mutation_power*np.random.randn()                         #noise get standart nomal distribution value
                temp[j] = temp[j] + noise[j]                             #add noise to original parameter
            temp = temp.reshape(np.shape(self.model.q_value.W.data))   #reshape renewaled parameter to original shape
            self.model.q_value.W.data=copy.deepcopy(temp)




        if algorithm==1: #(DE:Differencial Evolution)
            F=0.8     #F=[0~2]
            CR=0.8  #CR=[0~1]
            self.size=size
            self.rank=rank
            
            #start DE
            sum_of_rewards=0
            
            for i in range(0,self.size):
                sum_of_rewards+=weights_of_CNN[i][1]
            self.child_reward=sum_of_rewards

            #compare the parent and the child
            if self.parent_reward < self.child_reward:
                self.parent_weights[0]=copy.deepcopy(weights_of_CNN[self.rank][0][0])
                self.parent_weights[1]=copy.deepcopy(weights_of_CNN[self.rank][0][1])
                self.parent_weights[2]=copy.deepcopy(weights_of_CNN[self.rank][0][2])
                self.parent_weights[3]=copy.deepcopy(weights_of_CNN[self.rank][0][3])
                self.parent_weights[4]=copy.deepcopy(weights_of_CNN[self.rank][0][4])
                self.parent_weights[5]=copy.deepcopy(weights_of_CNN[self.rank][0][5])
                self.parent_reward = self.child_reward

            #select remaining 3 parents
            
            while True:
                parent_a=np.random.randint(self.size)
                if parent_a!=self.rank:
                    break

            while True:
                parent_b=np.random.randint(self.size)
                if parent_b!=self.rank and parent_b!=parent_a:
                    break
            while True:
                parent_c=np.random.randint(self.size)
                if parent_c!=self.rank and parent_c!=parent_a and parent_c!=parent_b:
                    break
            

            #make offspring
   
            st=time.time()
            #first convolutional layer
            child_weight= copy.deepcopy(self.model.conv1.W.data).reshape(-1)   #1 dim array 
            temp_root = self.parent_weights[0].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][0].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][0].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][0].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]

            child_weight = child_weight.reshape(np.shape(self.model.conv1.W.data))   #reshape renewaled parameter to original shape
            self.model.conv1.W.data=copy.deepcopy(child_weight)


            #second convolutional layer
            child_weight= copy.deepcopy(self.model.conv2.W.data).reshape(-1)   #1 dim array 
            temp_root = self.parent_weights[1].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][1].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][1].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][1].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]
            child_weight = child_weight.reshape(np.shape(self.model.conv2.W.data))   #reshape renewaled parameter to original shape
            self.model.conv2.W.data=copy.deepcopy(child_weight)


            #third convolutional layer
            child_weight= copy.deepcopy(self.model.conv3.W.data).reshape(-1)   #1 dim array 
            temp_root = self.parent_weights[2].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][2].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][2].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][2].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]
            child_weight = child_weight.reshape(np.shape(self.model.conv3.W.data))   #reshape renewaled parameter to original shape
            self.model.conv3.W.data=copy.deepcopy(child_weight)


            #fourth convolutional layer
            child_weight= copy.deepcopy(self.model.conv4.W.data).reshape(-1)   #1 dim array 
            temp_root = self.parent_weights[3].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][3].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][3].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][3].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]
            child_weight = child_weight.reshape(np.shape(self.model.conv4.W.data))   #reshape renewaled parameter to original shape
            self.model.conv4.W.data=copy.deepcopy(child_weight)


            #first dense layer
            child_weight= copy.deepcopy(self.model.l1.W.data).reshape(-1)   #1 dim array 
            temp_root = self.parent_weights[4].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][4].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][4].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][4].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]
            child_weight = child_weight.reshape(np.shape(self.model.l1.W.data))   #reshape renewaled parameter to original shape
            self.model.l1.W.data=copy.deepcopy(child_weight)


            #output layer
            child_weight= copy.deepcopy(self.model.q_value.W.data).reshape(-1)   #1 dim array 
            temp_root =self.parent_weights[5].reshape(-1)      
            temp_A = weights_of_CNN[parent_a][0][5].reshape(-1)   #parent A vector of weights in first convolutional layer
            temp_B = weights_of_CNN[parent_b][0][5].reshape(-1)   #parent B vector of weights in first convolutional layer
            temp_C = weights_of_CNN[parent_c][0][5].reshape(-1)   #parent C vector of weights in first convolutional layer
            for j in range(0,len(temp_root)):
                child_weight[j]=temp_A[j]+F*(temp_B[j]-temp_C[j]) #off spring vector was generated 
                #crossover
                u_i=np.random.rand()
                if CR < u_i:
                     child_weight[j]=temp_root[j]
            child_weight = child_weight.reshape(np.shape(self.model.q_value.W.data))   #reshape renewaled parameter to original shape
            self.model.q_value.W.data=copy.deepcopy(child_weight)



        if algorithm==2: #(more_mild GA)
            mutation_power=0.002
            mutation_prob=1.0
            
            if rank==0 or rank==1 or rank ==2:               # 3 machines select a 1st elite as parent
                parent_id=weights_of_CNN[0][1][0] 

            elif rank==3 or rank==4:
                parent_id=weights_of_CNN[0][1][1]            # 2 machines select a 2nd elite as parent

            else:
                parent_id=weights_of_CNN[0][1][2]            # a last machine select a 3rd elite as parent
            
            
            #regenerate 1st elite
            if rank==0:
                #first convolutional layer
                temp = weights_of_CNN[parent_id][0][0]    
                self.model.conv1.W.data=copy.deepcopy(temp)

                #second convolutional layer
                temp = weights_of_CNN[parent_id][0][1]     
                self.model.conv2.W.data=copy.deepcopy(temp)

                #third convolutional layer
                temp = weights_of_CNN[parent_id][0][2]     
                self.model.conv3.W.data=copy.deepcopy(temp)

                #fourth convolutional layer
                temp = weights_of_CNN[parent_id][0][3]     
                self.model.conv4.W.data=copy.deepcopy(temp)

                #first dense layer
                temp = weights_of_CNN[parent_id][0][4]    
                self.model.l1.W.data=copy.deepcopy(temp)

                #output layer
                temp = weights_of_CNN[parent_id][0][5]     
                self.model.q_value.W.data=copy.deepcopy(temp)


            else:
                #first convolutional layer
                temp = weights_of_CNN[parent_id][0][0].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.conv1.W.data))   #reshape renewaled parameter to original shape
                self.model.conv1.W.data=copy.deepcopy(temp)

                #second convolutional layer
                temp = weights_of_CNN[parent_id][0][1].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.conv2.W.data))   #reshape renewaled parameter to original shape
                self.model.conv2.W.data=copy.deepcopy(temp)

                #third convolutional layer
                temp = weights_of_CNN[parent_id][0][2].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.conv3.W.data))   #reshape renewaled parameter to original shape
                self.model.conv3.W.data=copy.deepcopy(temp)
    
                #fourth convolutional layer
                temp = weights_of_CNN[parent_id][0][3].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.conv4.W.data))   #reshape renewaled parameter to original shape
                self.model.conv4.W.data=copy.deepcopy(temp)

                #first dense layer
                temp = weights_of_CNN[parent_id][0][4].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.l1.W.data))   #reshape renewaled parameter to original shape
                self.model.l1.W.data=copy.deepcopy(temp)

                #output layer
                temp = weights_of_CNN[parent_id][0][5].reshape(-1)      
                for j in range(0,len(temp)):
                    noise=mutation_power*np.random.randn()               #noise get standart nomal distribution value
                    u_i=np.random.rand()
                    if u_i<mutation_prob:
                        temp[j] = temp[j] + noise                         #add noise to original parameter
                temp = temp.reshape(np.shape(self.model.q_value.W.data))   #reshape renewaled parameter to original shape
                self.model.q_value.W.data=copy.deepcopy(temp)

        if algorithm==3: #(tournament GA)
            print ("enter")
            mutation_power=0.02
            mutation_prob=1.0
            for i in range(0,self.num_of_controller):
                #print "weights_of_CNN",weights_of_CNN[i][0][0][0][0]
                #elite regeneration
                if rank==0 and i==0: 
                    #for 1st conv to output "weights"
                    for j in range(0,6):
                        temp = weights_of_CNN[i][j]    
                        self.controllers[i][j]=copy.deepcopy(temp)

                    #for BN parameters
                    if self.BN_evo!=0:
                        for j in range(6,14):
                            temp = weights_of_CNN[i][j]   
                            self.controllers[i][j]=copy.deepcopy(temp) 

                else:
                    #for 1st conv to output "weights"
                    
                    for j in range(0,6):
                        temp = weights_of_CNN[i][j].reshape(-1)
                        noise=mutation_power*np.random.randn(len(temp))
                        filter_=np.random.rand(len(temp))
                        #print "%",float(np.sum(filter_ < mutation_prob))/len(filter_)*100
                        noise=(filter_ < mutation_prob)*noise
                        noise=np.array(noise,dtype='float32')
                        temp = temp + cuda.to_gpu(noise)  
                        temp = temp.reshape(np.shape(cuda.to_cpu(self.controllers[0][j])))   #reshape renewaled parameter to original shape
                        self.controllers[i][j]=copy.deepcopy(temp)

                    #for BN parameters
                    if self.BN_evo!=0: 
                        for j in range(6,14):
                            temp = weights_of_CNN[i][j].reshape(-1)
                            noise=mutation_power*np.random.randn(len(temp))
                            filter_=np.random.rand(len(temp))
                            noise=(filter_ < mutation_prob)*noise
                            noise=np.array(noise,dtype='float32')
                            temp = temp + cuda.to_gpu(noise)  
                            temp = temp.reshape(np.shape(cuda.to_cpu(self.controllers[0][j])))   #reshape renewaled parameter to original shape
                            self.controllers[i][j]=copy.deepcopy(temp)





                    


